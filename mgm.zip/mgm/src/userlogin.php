<!DOCTYPE html>
<html>
    <head>
    <title>USER LOGIN</title>

        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/user.css">

<body>


<h1 style="text-align: center;">USER LOGIN</h1>
<div>
    <div class="topnav">
<a href="index.php">Home page </a>
<a href="adminlogin.php">Admin </a>
<a href="userlogin.php">User </a>
<a href="onlineshoppinglogin.php">Online Shopping </a>
<a href="customerlogin.php"> Customer</a>
    </div>

</div>
<br>
<form class="login" action="php/user_auth.php" method="post">
    <label for="fname">User name:</label><br>
    <input type="text" id="fname" name="username" value=""><br>
    <label for="lname">Password:</label><br>
    <input type="text" id="lname" name="password" value="">
    <br>
    <input class="button" type="submit" value="Submit">
<a href="user_registeration.php">new user ? sign up</a>
  </form>

</body>
</html>