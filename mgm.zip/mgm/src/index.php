<!DOCTYPE html>
<html>
    <head>
    <title>WELCOME</title>

        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/index.css">

<body>


<h1 style="text-align: center;">E-PLASTIC</h1>
<div>
    <div class="topnav">
<a href="index.php">Home page </a>
<a href="adminlogin.php">Admin </a>
<a href="userlogin.php">User </a>
<a href="onlineshoppinglogin.php">Online Shopping </a>
<a href="customerlogin.php"> Customer</a>
    </div>
    <div>
        <img src="assets/buckets1.jpg" alt="Nature" class="responsive">

    </div>
</div>
<h2 style="text-align: center;">WELCOME TO E PLASTIC</h2>

</body>
</html>