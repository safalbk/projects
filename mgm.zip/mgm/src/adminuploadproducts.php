<!DOCTYPE html>
<html>
    <head>
    <title>UPLOAD PRODUCTS</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/user_reg.css">

<body>


<h1 style="text-align: center;">Upload Products</h1>
<div>
    <div class="topnav">
        <a href="adminhome.php">Home page </a>
        <a href="adminuploadproducts.php">Upload Products </a>
        <a href="adminviewmaterials.php">View material</a>
        <a href="index.php"> Logout</a>
    </div>

</div>
<br>
<div >
   
    <form   action="php/db_admin_upload.php" method="post">
        <table class="logintable">
            <tr>
              <td> <label >Product name:</label></td>
              <td> <input type="text" id="password" name="name" value=""></td>
            </tr>
            <tr>
    
              <td><label >Quantity:</label></td>
              <td><input type="text" id="password" name="quantity" value=""></td>
    
    
            </tr>
            <tr>
                <td><label >Description:</label></td>
                <td><input type="text" id="gender" name="description" value=""></td>
    
            </tr>
            <tr>
                <td><label >Price:</label></td>
                <td><input type="text" id="dob" name="price" value=""></td>
    
                
            </tr>
            <tr>
                <td><label >Image:</label></td>
                <td>  <input type="file" id="image" name="image" accept="image/*"></td>
    
                
            </tr>
          </table>
          <div class="loginbuttona">
            <input class="button" type="submit" value="Upload">
          </div>
        
    </form>
</div>

</body>
</html>