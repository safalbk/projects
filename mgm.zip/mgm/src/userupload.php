<!DOCTYPE html>
<html>
    <head>
    <title>USER UPLOAD</title>

        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/user_reg.css">

<body>


<h1 style="text-align: center;">UPLOAD MATERIALS</h1>
<div>
    <div class="topnav">
      <a href="userhome.php">Home page </a>
      <a href="userupload.php">Upload material </a>
      <a href="userviewmaterials.php">View material Status </a>
      <a href="index.php"> Logout</a>
    </div>

</div>
<br>
<div >
   
    <form   action="php/db_user_m_upload.php" method="post">
        <table class="logintable">
            <tr>
              <td> <label >Material name:</label></td>
              <td> <input type="text" id="password" name="name" value=""></td>
            </tr>
            <tr>
    
              <td><label >Quantity:</label></td>
              <td><input type="text" id="password" name="quantity" value=""></td>
    
    
            </tr>
            <tr>
                <td><label >Description:</label></td>
                <td><input type="text" id="gender" name="description" value=""></td>
    
            </tr>
            <tr>
                <td><label >price:</label></td>
                <td><input type="text" id="dob" name="price" value=""></td>
            </tr>
          </table>
          <div class="loginbuttona">
            <input class="button" type="submit" value="Upload">
          </div>
        
    </form>
</div>

</body>
</html>