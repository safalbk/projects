<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/index.css">

<body>


<h1 style="text-align: center;">E-PLASTIC</h1>
<div>
    <div class="topnav">
<a href="onlineshoppinghome.php">Home page </a>
<a href="onlineshoppingviewproducts.php">View Products </a>
<a href="index.php"> Logout</a>
    </div>
    <div>
        <img src="assets/buckets1.jpg" alt="Nature" class="responsive">

    </div>
</div>
<h2 style="text-align: center;">
<?php 
session_start();
echo "WELCOME ".$_SESSION["s_current_user"];
?>
</h2>

</body>
</html>