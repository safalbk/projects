<!DOCTYPE html>
<html>
    <head>
    <title>CUSTOMER PURCHASE</title>

        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/viewuploads.css">

<body>


<h1 style="text-align: center;">CUSTOMER PURCHASE</h1>
<div>
    <div class="topnav">
        <a href="customerhome.php">Home page </a>
        <a href="customerpurchase.php">Purchase Products </a>
        <a href="index.php"> Logout</a>
    </div>

</div>
<br>
<table  >
    <tr >
        <th >Product Name </th>
        <th>Product Quantity </th>
        <th>Product Description </th>
        <th>Product Price </th>
        <th>Image </th>
        <th>Purchase </th>
    </tr>
    <?php
session_start();
$con = mysqli_connect("localhost","root","","mgm");

if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}

$sql="SELECT * FROM `products` WHERE 1";
if ($result = mysqli_query($con, $sql)) {
    foreach($result as $item)
    {
//         // id``p_name``p_quantity``p_desc``p_price``p_image`
        echo "<tr> 
        <th > ".$item["p_name"]." </th>
        <th > ".$item["p_quantity"]." </th> 
        <th > ".$item["p_desc"]." </th> 
        <th > ".$item["p_price"]." </th> 
        <th > <img src='assets/".$item["p_image"]."' alt='products' width='100' height='100'> </th> 
        <td>  <a href='customerbuy.php?id=".$item["id"]."'>Purchase</a> </td>
         </tr>" ;
         
    }

//   mysqli_free_result($result);
}
mysqli_close($con);

?>
  </table>

</body>
</html>