<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/viewuploads.css">

<body>


<h1 style="text-align: center;">User Registration</h1>
<div>
    <div class="topnav">
        <a href="adminhome.php">Home page </a>
        <a href="adminuploadproducts.php">Upload Products </a>
        <a href="adminviewmaterials.php">View material</a>
        <a href="index.php"> Logout</a>
    </div>

</div>
<br>
<table  >
    <tr >
        <th >Material Name </th>
        <th>Material Quantity </th>
        <th>Material Description </th>
        <th>Material Price </th>
        <th>User </th>
        <th>Status </th>
        <th>Accept </th>
    </tr>
    <?php
session_start();
$con = mysqli_connect("localhost","root","","mgm");

if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}

$sql="SELECT * FROM `material` WHERE 1";
if ($result = mysqli_query($con, $sql)) {
    foreach($result as $item)
    {
        // `m_id`, `m_name`, `m_quantity`, `m_description`,`m_price`, `m_user`, `m_status`
        echo "<tr> 
        <td > ".$item["m_name"]." </td>
        <td > ".$item["m_quantity"]." </td> 
        <td > ".$item["m_description"]." </td> 
        <td > ".$item["m_price"]." </td> 
        <td > ".$item["m_user"]." </td> 
        <td > ".$item["m_status"]." </td> 
        <td>  <a href='php/accept.php?id=".$item["m_id"]."'>Accept</a> </td>
         </tr>" ;

    }

  mysqli_free_result($result);
}
mysqli_close($con);

?>
  </table>

</body>
</html>