<!DOCTYPE html>
<html>
    <head>
    <title>ADMIN LOGIN</title>

        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/user.css">

<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = mysqli_connect($servername, $username, $password);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
// echo "Connected successfully";
?>

<h1 style="text-align: center;">ADMIN LOGIN</h1>
<div>
    <div class="topnav">
<a href="index.php">Home page </a>
<a href="adminlogin.php">Admin </a>
<a href="userlogin.php">User </a>
<a href="onlineshoppinglogin.php">Online Shopping </a>
<a href="customerlogin.php"> Customer</a>
    </div>

</div>
<br>

<form action="php/admin_auth.php" method="post" class="login">
    
    <label for="lname">Password:</label><br>
    <input type="text" id="password" name="password" value="">
    <br>
    <input class="button" type="submit" value="Login">
  </form>

</body>
</html>