<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/index.css">

<body>


<h1 style="text-align: center;">E-PLASTIC</h1>
<div>
    <div class="topnav">
        <a href="adminhome.php">Home page </a>
        <a href="adminuploadproducts.php">Upload Products </a>
        <a href="adminviewmaterials.php">View material</a>
        <a href="index.php"> Logout</a>
    </div>
    <div>
        <img src="assets/buckets1.jpg" alt="Nature" class="responsive">

    </div>
</div>
<h2 style="text-align: center;">WELCOME Admin </h2>

</body>
</html>