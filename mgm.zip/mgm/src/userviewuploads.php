<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/viewuploads.css">

<body>


<h1 style="text-align: center;">User Registration</h1>
<div>
    <div class="topnav">
        <a href="userhome.php">Home page </a>
        <a href="userupload.php">Upload material </a>
        <a href="userviewmaterials.php">View material Status </a>
        <a href="index.php"> Logout</a>
    </div>

</div>
<br>
<table  >
    <tr >
        <th >Material Name </th>
        <th>Material Quantity</th>
        <th>Material Description</th>
        <th>Material Price</th>
        <th>User</th>
        <th>Status</th>

    </tr>
 
  </table>

</body>
</html>