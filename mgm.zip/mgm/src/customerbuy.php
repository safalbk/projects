<!DOCTYPE html>
<html>
    <head>
    <title>BUY</title>

        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/buy.css">
        <script src="js/checkq.js"></script>
</head>
<body>


<h1 style="text-align: center;">Customer Buy</h1>
<div>
    <div class="topnav">
        <a href="customerhome.php">Home page </a>
        <a href="customerpurchase.php">Purchase Product </a>
        <a href="index.php"> Logout</a>
    </div>

</div>
<br>
<div >
   
    <form  id="cus_form" action="customerpay.php" method="post">

        <table class="logintable">
<?php
session_start();
$id=intval($_GET['id']);
$con = mysqli_connect("localhost","root","","mgm");
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}
$sql="SELECT * FROM `products` WHERE `id`='".$id."'";
if ($result = mysqli_query($con, $sql)) {
    foreach($result as $item){
echo " <tr>
    <td> <label >Product Id:</label></td>
    <td> <input type='text' id='p_id' name='p_id' value='".$item["id"]."'></td>
    </tr>
    <tr>
    <td> <label >Product Name:</label></td>
    <td> <input type='text' id='p_name' name='p_name' value='".$item['p_name']."'></td>
    </tr>
    <tr>
      <td><label >Description:</label></td>
      <td><input type='text' id='p_description' name='p_description' value='".$item['p_desc']."'></td>
    
    </tr>
    
    <tr>
      <td><label >Price:</label></td>
      <td><input type='text' id='p_price' name='p_price' value='".$item['p_price']."'></td>
    
      
    </tr>
  
    <tr>
    <td><p align='center'>Available stocks </p></td>
    <td><p id='stocks'align='center'>".$item["p_quantity"]."</p></td>
    </tr> ";
    $_SESSION["real_quantity"]=$item["p_quantity"];
    }
  mysqli_free_result($result);
}
mysqli_close($con);
?>
  <tr>
    <td><label >Quantity:</label></td>
    <td><input oninput="myFunction()" type="text" id="count" name="p_quantity" value=""></td>
  </tr>  
    </table>
        
        <div class="loginbuttona">
        <input  id='sub' class="button" onclick="b_submit()" type="button" value="Submit">
        </div>
        
    </form>

</div>
</body>

</html>