<!DOCTYPE html>
<html>
    <head>
        <title>USER REGISTRATION</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/user_reg.css">

<body>


<h1 style="text-align: center;">User Registration</h1>
<div>
    <div class="topnav">
        <a href="index.php">Home page </a>
        <a href="adminlogin.php">Admin </a>
        <a href="userlogin.php">User </a>
        <a href="onlineshoppinglogin.php">Online Shopping </a>
        <a href="customerlogin.php"> Customer</a>
    </div>

</div>
<br>
<div >
   
    <form  id="thisform" action="php/db_user_registeration.php" method="post">
        <table class="logintable">
            <tr>
              <td> <label >User name:</label></td>
              <td> <input type="text" id="password" name="username" value=""></td>
            </tr>
            <tr>
    
              <td><label >Password:</label></td>
              <td><input type="password" id="password" name="password" value=""></td>
    
    
            </tr>
            <tr>
                <td><label >Gender:</label></td>
                <td><select style="margin: 10px;" name="gender" id="gender">
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    
                </select>
                </td>
    
            </tr>
            <tr>
                <td><label >Date Of Birtd:</label></td>
                <td><input type="date" id="dob" name="dob" value=""></td>
    
                
            </tr>
            <tr>
                <td><label >Mobile NO:</label></td>
                <td><input type="text" id="mobno" name="mobno" value=""></td>
    
            </tr>
            <tr>
                <td><label >Email:</label></td>
                <td><input type="email" id="email" name="email" value=""></td>
    
            </tr>
            <tr>
                <td><label >Address:</label></th>
                <td>
                <textarea form="thisform"style="margin: 10px;" id="address" name="address" rows="4" cols="17"></textarea>
                </td>
    
            </tr>
          </table>
          <div class="loginbuttona">
            <input class="button" type="submit" value="Register">
          </div>
        
    </form>
</div>

</body>
</html>