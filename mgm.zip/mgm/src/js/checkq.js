function myFunction() {
    var stocks=document.getElementById("stocks").innerHTML;
    stocks=parseInt(stocks);
    var quantity = document.getElementById("count").value;
    quantity=parseInt(quantity);
    // alert(quantity+" "+stocks);

    if(quantity>stocks)
    {
        alert("not enough stocks");

    }
    if(quantity>stocks)
    {
        // alert("not enough stocks");
        document.getElementById("sub").style.visibility = "hidden";

    }
    else{
        document.getElementById("sub").style.visibility = "visible";

    }

  }
  function b_submit() {
    document.getElementById("cus_form").submit();

    // alert("submitted");
  }