<?php
$v_password = $_POST["password"];

$con = mysqli_connect("localhost","root","","mgm");

if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}
$sql="INSERT INTO `users` (`id`, `username`, `password`, `gender`, `dob`, `mob_no`, `email`, `address`) 
VALUES (NULL, 'amal', '123', 'male', '04-12-1997', '8129226432', 'safalbk333@gmail.com', 
'saranalayam kannampally bhagam kayamkulam po')";
// $sql="SELECT * FROM logindb WHERE username = 'admin' AND pword ='".$v_password."' ";
// $sql="SELECT * FROM logindb WHERE 1"
// $sql="SELECT username FROM logindb WHERE username = 'admin'";
// SELECT `username` FROM `logindb` WHERE `username`='admin';
// // Perform query
mysqli_query($con, $sql);
mysqli_close($con);

?>