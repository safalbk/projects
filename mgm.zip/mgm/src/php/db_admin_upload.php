<?php
$v_username = $_POST["name"];
$v_password = $_POST["quantity"];
$v_des = $_POST["description"];
$v_price = $_POST["price"];
$v_img = $_POST["image"];

// echo $v_username ;
// echo $v_password;
// echo $v_des ;
// echo $v_price ;
// echo $v_img ;
$con = mysqli_connect("localhost","root","","mgm");

if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}
$sql="INSERT INTO `products` (`id`, `p_name`, `p_quantity`, `p_desc`, `p_price`, `p_image`) VALUES 
(NULL, '".$v_username."', '".$v_password."', '".$v_des."', '".$v_price."', '".$v_img."')";
if ( mysqli_query($con, $sql)) {
  // Free result set\
  header("Location: ../adminuploadproducts.php");
  die();
}
else{
    header("Location: ../adminuploadproducts.php");
    die();
  }
mysqli_close($con); 
?>