<?php
session_start();

$v_username = $_POST["name"];
$v_quantity = $_POST["quantity"];
$v_des = $_POST["description"];
$v_price = $_POST["price"];


$con = mysqli_connect("localhost","root","","mgm");

if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}

$sql="INSERT INTO `material` (`m_id`, `m_name`, `m_quantity`, `m_description`,`m_price`, `m_user`, `m_status`)
 VALUES (NULL, '".$v_username."', '".$v_quantity."', '".$v_des."','".$v_price."', '".$_SESSION["s_current_user"]."', 'pending')";
if(mysqli_query($con, $sql))
{
  header("Location: ../userupload.php");
  die();
}
else{
  header("Location: ../userupload.php");
  die();
}
// $sql="SELECT * FROM logindb WHERE username = 'admin' AND pword ='".$v_password."' ";
// $sql="SELECT * FROM logindb WHERE 1"
// $sql="SELECT username FROM logindb WHERE username = 'admin'";
// SELECT `username` FROM `logindb` WHERE `username`='admin';
// // Perform query
mysqli_query($con, $sql);
mysqli_close($con);

?>