<?php
$v_username = $_POST["username"];
$v_password = $_POST["password"];
$v_gender = $_POST["gender"];
$v_dob = $_POST["dob"];
$v_mobno= $_POST["mobno"];
$v_email = $_POST["email"];
$v_address = $_POST["address"];
echo $v_address;
$con = mysqli_connect("localhost","root","","mgm");

if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}
$sql="INSERT INTO `logindb` (`id`, `username`, `pword`) VALUES (NULL, '".$v_username."', '".$v_password."')";

mysqli_query($con, $sql);
$sql="INSERT INTO `users` (`id`, `username`, `password`, `gender`, `dob`, `mob_no`, `email`, `address`) 
VALUES (NULL, '".$v_username."', '".$v_password."', '".$v_gender."', '".$v_dob."', '".$v_mobno."', '".$v_email."','".$v_address."')";
if(mysqli_query($con, $sql))
{
  header("Location: ../userlogin.php");
  die();
}
else{
  header("Location: ../userlogin.php");
  die();
}
// $sql="SELECT * FROM logindb WHERE username = 'admin' AND pword ='".$v_password."' ";
// $sql="SELECT * FROM logindb WHERE 1"
// $sql="SELECT username FROM logindb WHERE username = 'admin'";
// SELECT `username` FROM `logindb` WHERE `username`='admin';
// // Perform query
mysqli_query($con, $sql);
mysqli_close($con);

?>