<?php
session_start();
$id = $_SESSION["p_id"];
$quantity = $_SESSION["p_quantity"];
echo "purchase";
$con = mysqli_connect("localhost","root","","mgm");
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}
 $f_quantity=intval($_SESSION["real_quantity"])-intval($quantity);
$sql="UPDATE `products` SET `p_quantity` = '".$f_quantity."' WHERE `products`.`id` = '".$id."'";
if (mysqli_query($con, $sql)) {
    header("Location: ../customerpurchase.php");
    die();
    session_destroy();
}
else{
    echo "        <p style='color: red; font-size: 50px; text-align: center;  '>PURCHASE CANCELED</p>
    ";
}
mysqli_close($con);

?>