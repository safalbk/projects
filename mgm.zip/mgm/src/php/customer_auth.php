<?php
session_start();
$v_username = $_POST["username"];
$v_password = $_POST["password"];
$con = mysqli_connect("localhost","root","","mgm");
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}
$sql="SELECT * FROM logindb WHERE username = '".$v_username."' AND pword ='".$v_password."' ";
// $sql="SELECT * FROM logindb WHERE 1"
// $sql="SELECT username FROM logindb WHERE username = 'admin'";
// SELECT `username` FROM `logindb` WHERE `username`='admin';
// // Perform query
if ($result = mysqli_query($con, $sql)) {
  echo "Returned rows are: " . mysqli_num_rows($result);
  // Free result set\
  if(mysqli_num_rows($result)==1)
  {
    $_SESSION["s_current_user"]=$v_username;
    header("Location: ../customerhome.php");
    die();
  }
  else{
    header("Location: ../customerlogin.php");
    die();
  }
  mysqli_free_result($result);
}
mysqli_close($con);

?>