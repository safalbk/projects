
<?php
// echo $_GET['id'];
$id=intval($_GET['id']);
$con = mysqli_connect("localhost","root","","mgm");

if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}
$sql="UPDATE `material` SET `m_status` = 'accepted' WHERE `material`.`m_id` = ".$id."";
if (mysqli_query($con, $sql)) {

    header("Location: ../adminviewmaterials.php");
    die();
}

else{
    header("Location: ../adminviewmaterials.php");
    die();
  }
mysqli_close($con);

?>