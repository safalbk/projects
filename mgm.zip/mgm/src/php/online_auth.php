<?php
session_start();

$v_username = $_POST["username"];
$v_password = $_POST["password"];
$con = mysqli_connect("localhost","root","","mgm");
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}
$sql="SELECT * FROM logindb WHERE username = '".$v_username."' AND pword ='".$v_password."' ";
// $sql="SELECT * FROM logindb WHERE 1"
// $sql="SELECT username FROM logindb WHERE username = 'admin'";
// SELECT `username` FROM `logindb` WHERE `username`='admin';
// // Perform query
if (mysqli_query($con, $sql)) 
  {
    $_SESSION["s_current_user"]=$v_username;

    header("Location: ../onlineshoppinghome.php");
    die();
  }
  else{
    header("Location: ../onlineshoppinghome.php");
    die();
  }
  
mysqli_close($con);

?>