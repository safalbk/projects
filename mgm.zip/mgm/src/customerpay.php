<!DOCTYPE html>
<html>
    <head>
    <title>BANK DETAILS</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/bank.css">

<body>


<h1 style="text-align: center;">Bank Details</h1>
<div>
    <div class="topnav">
        <a href="customerhome.php">Home page </a>
        <a href="customerpurchase.php">Purchase Product </a>
        <a href="index.php"> Logout</a>
    </div>

</div>
<br>
<div >
   
    <form   action="php/purchase.php" method="post">

        <table class="logintable">
<?php
$id =$_POST["p_id"];
$name =$_POST["p_name"];
$des = $_POST["p_description"];
$price = intval($_POST["p_price"]);
$quantity  =intval($_POST["p_quantity"]);
echo "<tr>
<td> <label >Product Id:</label></td>
<td> <label >".$id."</label></td>
</tr>
<tr>
<td> <label >Product Name:</label></td>
<td> <label >".$name."</label></td>
</tr>
<tr>
<td><label >Description:</label></td>
<td><label >".$des."</label></td>

</tr>
<tr>
<td><label >Quantity:</label></td>
<td><label >".$quantity."</label></td>
</tr>
<tr>
<td><label >Total Cost:</label></td>
<td><label >".$quantity * $price."</label></td>
</tr>
<tr>
<td><label >Card Number:</label></td>
<td><input type='text' id='p_cardno' name='p_cardno' value=''></td>
</tr>
<tr>
<td><label >CVV:</label></td>
<td><input type='text' id='p_cvv' name='p_cvv' value=''></td>
</tr>";
session_start();
$_SESSION["p_id"]=$id;
$_SESSION["p_quantity"]=$quantity;
?>
        </table>
        
        <div class="loginbuttona">
            <input class="button" name="b_submit" type="submit" value="Submit">
        </div>
        
    </form>
    
</div>

</body>
</html>
